const menuemoji = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✮𝐄𝐌𝐎𝐉𝐈 』
╭════════════════════╯
 | ೈ፝͜͡😃 ${prefix}emoji 😭/apple
 | ೈ፝͜͡😃 ${prefix}emoji 😭/samsung
 | ೈ፝͜͡😃 ${prefix}emoji 😭/whatsapp
 | ೈ፝͜͡😃 ${prefix}emoji 😭/google
 | ೈ፝͜͡😃 ${prefix}emoji 😭/microsoft
 | ೈ፝͜͡😃 ${prefix}emoji 😭/twitter
 | ೈ፝͜͡😃 ${prefix}emoji 😭/facebook
 | ೈ፝͜͡😃 ${prefix}emoji 😭/joypixels
 | ೈ፝͜͡😃 ${prefix}emoji 😭/openmoji
 | ೈ፝͜͡😃 ${prefix}emoji 😭/emojidix
 | ೈ፝͜͡😃 ${prefix}emoji 😭/notomoji
 | ೈ፝͜͡😃 ${prefix}emoji 😭/emojipedia
 | ೈ፝͜͡😃 ${prefix}emoji 😭/skype
 | ೈ፝͜͡😃 ${prefix}emoji 😭/ig
 | ೈ፝͜͡😃 ${prefix}emoji 😭/htc
╰════════════════════╮`
}

exports.menuemoji = menuemoji