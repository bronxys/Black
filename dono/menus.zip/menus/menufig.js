const menufig = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✮𝐅𝐈𝐆𝐔𝐑𝐈𝐍𝐇𝐀𝐒 』
╭════════════════════╯
 | ೈ፝͜͡💝 ${prefix}s (marcar foto ou vídeo)
 | ೈ፝͜͡💝 ${prefix}f (marcar foto ou vídeo)
 | ೈ፝͜͡💝 ${prefix}toimg (marcar figurinha)
 | ೈ፝͜͡💝 ${prefix}togif (figurinha animada)
 | ೈ፝͜͡💝 ${prefix}sfundo (marcar foto)
 | ೈ፝͜͡💝 ${prefix}fblack (marcar figu)
 | ೈ፝͜͡💝 ${prefix}roubar (marcar figu)
 | ೈ፝͜͡💝 ${prefix}wpp (texto)
 | ೈ፝͜͡💝 ${prefix}attp
 | ೈ፝͜͡💝 ${prefix}attp2
 | ೈ፝͜͡💝 ${prefix}attp3
 | ೈ፝͜͡💝 ${prefix}attp4
 | ೈ፝͜͡💝 ${prefix}attp5
 | ೈ፝͜͡💝 ${prefix}attp6
 | ೈ፝͜͡💝 ${prefix}ttp
 | ೈ፝͜͡💝 ${prefix}figurinhas
 | ೈ፝͜͡💝 ${prefix}figurinhas2
 | ೈ፝͜͡💝 ${prefix}figemoji
 | ೈ፝͜͡💝 ${prefix}figflork
 | ೈ፝͜͡💝 ${prefix}figale
 | ೈ፝͜͡💝 ${prefix}figmemes
 | ೈ፝͜͡💝 ${prefix}figanime
 | ೈ፝͜͡💝 ${prefix}figcoreana
 | ೈ፝͜͡💝 ${prefix}figbebe
 | ೈ፝͜͡💝 ${prefix}figdesenho
 | ೈ፝͜͡💝 ${prefix}figanimais
 | ೈ፝͜͡💝 ${prefix}figengracada
 | ೈ፝͜͡💝 ${prefix}figraiva
 | ೈ፝͜͡💝 ${prefix}figroblox
 | ೈ፝͜͡💝 ${prefix}amongsticker
 | ೈ፝͜͡💝 ${prefix}emoji 😭
 | ೈ፝͜͡💝 ${prefix}emojimix 😑+😮‍💨
 | ೈ፝͜͡💝 ${prefix}placaloli (texto)
 | ೈ፝͜͡💝 ${prefix}legenda (marcar foto)
╰════════════════════╮`
}

exports.menufig = menufig