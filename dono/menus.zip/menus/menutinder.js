const menutinder = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✮𝐓𝐈𝐍𝐃𝐄𝐑 』
╭═══════════════════╯
 | ೈ፝͜͡❤️‍🔥 ${prefix}rgtinder
 | ೈ፝͜͡❤️‍🔥 ${prefix}meutinder
 | ೈ፝͜͡❤️‍🔥 ${prefix}tinder
 | ೈ፝͜͡❤️‍🔥 ${prefix}tindernome
 | ೈ፝͜͡❤️‍🔥 ${prefix}tinderidade
 | ೈ፝͜͡❤️‍🔥 ${prefix}setgene
 | ೈ፝͜͡❤️‍🔥 ${prefix}setfiltro
 | ೈ፝͜͡❤️‍🔥 ${prefix}setsex
 | ೈ፝͜͡❤️‍🔥 ${prefix}tinderbio
 | ೈ፝͜͡❤️‍🔥 ${prefix}tinderfoto
 | ೈ፝͜͡❤️‍🔥 ${prefix}sairtinder
 | ೈ፝͜͡❤️‍🔥 ${prefix}casacomigo @
 | ೈ፝͜͡❤️‍🔥 ${prefix}cancelar (cancela o pedido de casamento)
 | ೈ፝͜͡❤️‍🔥 ${prefix}divorciar
╰═══════════════════╮`
}

exports.menutinder = menutinder