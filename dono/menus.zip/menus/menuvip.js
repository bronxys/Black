const menuvip = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✰𝐕𝐈𝐏 』
╭════════════════════╯
 | ೈ፝͜͡🤑 ${prefix}gerarcpf
 | ೈ፝͜͡🤑 ${prefix}gerarnmr 
 | ೈ፝͜͡🤑 ${prefix}docfake 
 | ೈ፝͜͡🤑 ${prefix}recrutar (apenas ADM)
 | ೈ፝͜͡🤑 ${prefix}recrutar2 (apenas ADM)
 | ೈ፝͜͡🤑 ${prefix}ausente
 | ೈ፝͜͡🤑 ${prefix}ativo
 | ೈ፝͜͡🤑 ${prefix}delete
 | ೈ፝͜͡🤑 ${prefix}dam (apaga a sua msg tbm)
 | ೈ፝͜͡🤑 ${prefix}lerfoto
 | ೈ፝͜͡🤑 ${prefix}igstalk
 | ೈ፝͜͡🤑 ${prefix}mediafire
 | ೈ፝͜͡🤑 ${prefix}s2 (figu sem legenda)
 | ೈ፝͜͡🤑 ${prefix}gpt (Lucas, no PV)
 | ೈ፝͜͡🤑 ${prefix}Katy (no PV)
 | ೈ፝͜͡🤑 ${prefix}Jeff (no PV)
 | ೈ፝͜͡🤑 ${prefix}menu+18 (no PV)
╰════════════════════╮
『 𝐏𝐔𝐗𝐀𝐃𝐀𝐒 』
╭════════════════════╯
 | ೈ፝͜͡🤑 ${prefix}nome
 | ೈ፝͜͡🤑 ${prefix}nome2
 | ೈ፝͜͡🤑 ${prefix}nome3
 | ೈ፝͜͡🤑 ${prefix}nome4
 | ೈ፝͜͡🤑 ${prefix}tel
 | ೈ፝͜͡🤑 ${prefix}tel2
 | ೈ፝͜͡🤑 ${prefix}telfixo
 | ೈ፝͜͡🤑 ${prefix}cpf
 | ೈ፝͜͡🤑 ${prefix}cpf2
 | ೈ፝͜͡🤑 ${prefix}cpf3
 | ೈ፝͜͡🤑 ${prefix}cpf4
 | ೈ፝͜͡🤑 ${prefix}cpf5
 | ೈ፝͜͡🤑 ${prefix}placa
 | ೈ፝͜͡🤑 ${prefix}placa2
 | ೈ፝͜͡🤑 ${prefix}bin
 | ೈ፝͜͡🤑 ${prefix}site
 | ೈ፝͜͡🤑 ${prefix}ip
 | ೈ፝͜͡🤑 ${prefix}cep
 | ೈ፝͜͡🤑 ${prefix}vizinhos
 | ೈ፝͜͡🤑 ${prefix}cnpj
 | ೈ፝͜͡🤑 ${prefix}score
 | ೈ፝͜͡🤑 ${prefix}titulo
 | ೈ፝͜͡🤑 ${prefix}email
 | ೈ፝͜͡🤑 ${prefix}vacina
 | ೈ፝͜͡🤑 ${prefix}parentes
 | ೈ፝͜͡🤑 ${prefix}rg
 | ೈ፝͜͡🤑 ${prefix}rg2
 | ೈ፝͜͡🤑 ${prefix}senha
 | ೈ፝͜͡🤑 ${prefix}mae
 | ೈ፝͜͡🤑 ${prefix}pai
 | ೈ፝͜͡🤑 ${prefix}chassi
 | ೈ፝͜͡🤑 ${prefix}motor
 | ೈ፝͜͡🤑 ${prefix}beneficios
 | ೈ፝͜͡🤑 ${prefix}impostos
 | ೈ፝͜͡🤑 ${prefix}nascimento
 | ೈ፝͜͡🤑 ${prefix}cns
 | ೈ፝͜͡🤑 ${prefix}cns2
 | ೈ፝͜͡🤑 ${prefix}correios
 | ೈ፝͜͡🤑 ${prefix}dominio
╰════════════════════╮`
}

exports.menuvip = menuvip