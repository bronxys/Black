const menunsfw = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✮18 』
╭════════════════════╯
 | ೈ፝͜͡🔞 ${prefix}loli
 | ೈ፝͜͡🔞 ${prefix}trap
 | ೈ፝͜͡🔞 ${prefix}ass
 | ೈ፝͜͡🔞 ${prefix}ahegao
 | ೈ፝͜͡🔞 ${prefix}bdsm
 | ೈ፝͜͡🔞 ${prefix}blowjob
 | ೈ፝͜͡🔞 ${prefix}cuckold
 | ೈ፝͜͡🔞 ${prefix}cum
 | ೈ፝͜͡🔞 ${prefix}ero
 | ೈ፝͜͡🔞 ${prefix}femdom
 | ೈ፝͜͡🔞 ${prefix}foot
 | ೈ፝͜͡🔞 ${prefix}gangbang
 | ೈ፝͜͡🔞 ${prefix}ganbganb
 | ೈ፝͜͡🔞 ${prefix}glasses
 | ೈ፝͜͡🔞 ${prefix}hentai
 | ೈ፝͜͡🔞 ${prefix}hentai2
 | ೈ፝͜͡🔞 ${prefix}nekos
 | ೈ፝͜͡🔞 ${prefix}neko2
 | ೈ፝͜͡🔞 ${prefix}jahy
 | ೈ፝͜͡🔞 ${prefix}masturbation
 | ೈ፝͜͡🔞 ${prefix}orgy
 | ೈ፝͜͡🔞 ${prefix}panties
 | ೈ፝͜͡🔞 ${prefix}pussy
 | ೈ፝͜͡🔞 ${prefix}boobs
 | ೈ፝͜͡🔞 ${prefix}tentacles
 | ೈ፝͜͡🔞 ${prefix}thighs
 | ೈ፝͜͡🔞 ${prefix}yuri
 | ೈ፝͜͡🔞 ${prefix}zettai
 | ೈ፝͜͡🔞 ${prefix}kasedaiki
 | ೈ፝͜͡🔞 ${prefix}plaq
 | ೈ፝͜͡🔞 ${prefix}plaq2
 | ೈ፝͜͡🔞 ${prefix}plaq3
 | ೈ፝͜͡🔞 ${prefix}plaq4
 | ೈ፝͜͡🔞 ${prefix}plaq5
 | ೈ፝͜͡🔞 ${prefix}plaq6
╰════════════════════╮
『 𝐀𝐑𝐄𝐀✮𝐕𝐈𝐏 』
╭════════════════════╯
 | ೈ፝͜͡🔞 ${prefix}aline
 | ೈ፝͜͡🔞 ${prefix}alifox
 | ೈ፝͜͡🔞 ${prefix}alycai
 | ೈ፝͜͡🔞 ${prefix}amichan
 | ೈ፝͜͡🔞 ${prefix}aninha
 | ೈ፝͜͡🔞 ${prefix}baby
 | ೈ፝͜͡🔞 ${prefix}belle
 | ೈ፝͜͡🔞 ${prefix}brenda
 | ೈ፝͜͡🔞 ${prefix}cami
 | ೈ፝͜͡🔞 ${prefix}clowniac
 | ೈ፝͜͡🔞 ${prefix}galvao
 | ೈ፝͜͡🔞 ${prefix}giovanna
 | ೈ፝͜͡🔞 ${prefix}isadora
 | ೈ፝͜͡🔞 ${prefix}isa
 | ೈ፝͜͡🔞 ${prefix}lay
 | ೈ፝͜͡🔞 ${prefix}leticia
 | ೈ፝͜͡🔞 ${prefix}marina
 | ೈ፝͜͡🔞 ${prefix}maru
 | ೈ፝͜͡🔞 ${prefix}princesa
 | ೈ፝͜͡🔞 ${prefix}meadinha
 | ೈ፝͜͡🔞 ${prefix}nath
 | ೈ፝͜͡🔞 ${prefix}nega
 | ೈ፝͜͡🔞 ${prefix}polonesa
 | ೈ፝͜͡🔞 ${prefix}rute
 | ೈ፝͜͡🔞 ${prefix}vita
 | ೈ፝͜͡🔞 ${prefix}carnie
 | ೈ፝͜͡🔞 ${prefix}egril
 | ೈ፝͜͡🔞 ${prefix}neter
 | ೈ፝͜͡🔞 ${prefix}pornofot
 | ೈ፝͜͡🔞 ${prefix}amador
 | ೈ፝͜͡🔞 ${prefix}onlyfans
 | ೈ፝͜͡🔞 ${prefix}porno
 | ೈ፝͜͡🔞 ${prefix}egrilvideo
╰════════════════════╮`
}

exports.menunsfw = menunsfw