const menuadm = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✰𝐀𝐃𝐌 』
╭════════════════════╯
 | ೈ፝͜͡🎗️${prefix}ban (marca msg)
 | ೈ፝͜͡🎗️${prefix}band (marca msg)
 | ೈ፝͜͡🎗️${prefix}vasco (marca msg)
 | ೈ፝͜͡🎗️${prefix}kick @
 | ೈ፝͜͡🎗️${prefix}listanegra (número ou msg)
 | ೈ፝͜͡🎗️${prefix}tirardalista (número)
 | ೈ፝͜͡🎗️${prefix}listban
 | ೈ፝͜͡🎗️${prefix}mute @
 | ೈ፝͜͡🎗️${prefix}desmute @
 | ೈ፝͜͡🎗️${prefix}mutelist
 | ೈ፝͜͡🎗️${prefix}promover @
 | ೈ፝͜͡🎗️${prefix}rebaixar @
 | ೈ፝͜͡🎗️${prefix}linkgp
 | ೈ፝͜͡🎗️${prefix}sorteio
 | ೈ፝͜͡🎗️${prefix}infosorteio
 | ೈ፝͜͡🎗️${prefix}sorteionumero
 | ೈ፝͜͡🎗️${prefix}votação
 | ೈ፝͜͡🎗️${prefix}infovotação
 | ೈ፝͜͡🎗️${prefix}roleta
 | ೈ፝͜͡🎗️${prefix}roleta2
 | ೈ፝͜͡🎗️${prefix}limpar
 | ೈ፝͜͡🎗️${prefix}hidetag (mensagem)
 | ೈ፝͜͡🎗️${prefix}totag (marca alguma coisa)
 | ೈ፝͜͡🎗️${prefix}marcar
 | ೈ፝͜͡🎗️${prefix}marcar2
 | ೈ፝͜͡🎗️${prefix}marcarwa
 | ೈ፝͜͡🎗️${prefix}atividades
 | ೈ፝͜͡🎗️${prefix}criartabela
 | ೈ፝͜͡🎗️${prefix}tabelagp
 | ೈ፝͜͡🎗️${prefix}infogp
 | ೈ፝͜͡🎗️${prefix}listfake
 | ೈ፝͜͡🎗️${prefix}grupo a/f
 | ೈ፝͜͡🎗️${prefix}fechargp
 | ೈ፝͜͡🎗️${prefix}abrirgp
 | ೈ፝͜͡🎗️${prefix}bemvindo
 | ೈ፝͜͡🎗️${prefix}legendabv
 | ೈ፝͜͡🎗️${prefix}legendasaiu
 | ೈ፝͜͡🎗️${prefix}bemvindo2
 | ೈ፝͜͡🎗️${prefix}legendabv2
 | ೈ፝͜͡🎗️${prefix}legendasaiu2 
 | ೈ፝͜͡🎗️${prefix}fotogp
 | ೈ፝͜͡🎗️${prefix}descgp
 | ೈ፝͜͡🎗️${prefix}nomegp
 | ೈ፝͜͡🎗️${prefix}novolink
╰════════════════════╮
『 𝐀𝐓𝐈𝐕𝐀ÇÕ𝐄𝐒 』
╭════════════════════╯
 | ೈ፝͜͡🎗️${prefix}blockgp 1/0
 | ೈ፝͜͡🎗️${prefix}antiimg 1/0
 | ೈ፝͜͡🎗️${prefix}antivideo 1/0
 | ೈ፝͜͡🎗️${prefix}antiaudio 1/0
 | ೈ፝͜͡🎗️${prefix}antisticker 1/0
 | ೈ፝͜͡🎗️${prefix}antidoc 1/0
 | ೈ፝͜͡🎗️${prefix}antiloc 1/0
 | ೈ፝͜͡🎗️${prefix}antilinkhard 1/0
 | ೈ፝͜͡🎗️${prefix}antilinkgp 1/0
 | ೈ፝͜͡🎗️${prefix}antifake 1/0
 | ೈ፝͜͡🎗️${prefix}anticatalogo 1/0
 | ೈ፝͜͡🎗️${prefix}antipalavrao 1/0
 | ೈ፝͜͡🎗️${prefix}limiteflood 1/0
 | ೈ፝͜͡🎗️${prefix}bemvindo 1/0
 | ೈ፝͜͡🎗️${prefix}bemvindo2 1/0
 | ೈ፝͜͡🎗️${prefix}autosticker 1/0
 | ೈ፝͜͡🎗️${prefix}autoresposta 1/0
 | ೈ፝͜͡🎗️${prefix}modozoeira 1/0
 | ೈ፝͜͡🎗️${prefix}modonsfw 1/0
 | ೈ፝͜͡🎗️${prefix}leveling 1/0
╰════════════════════╮`
}

exports.menuadm = menuadm