const menumods = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✰𝐀𝐋𝐓𝐄𝐑𝐀𝐃𝐎𝐑𝐄𝐒 』
╭════════════════════╯
 | ೈ፝͜͡🧸 ${prefix}Videolento (marca)
 | ೈ፝͜͡🧸 ${prefix}Videorapido (marca)
 | ೈ፝͜͡🧸 ${prefix}reversemp4 (marca)
 | ೈ፝͜͡🧸 ${prefix}audiolento (marca)
 | ೈ፝͜͡🧸 ${prefix}audiorapido (marca)
 | ೈ፝͜͡🧸 ${prefix}grave (marca)
 | ೈ፝͜͡🧸 ${prefix}grave2 (marca)
 | ೈ፝͜͡🧸 ${prefix}esquilo (marca)
 | ೈ፝͜͡🧸 ${prefix}estourar (marca)
 | ೈ፝͜͡🧸 ${prefix}bass (marca)
 | ೈ፝͜͡🧸 ${prefix}bass2 (marca)
 | ೈ፝͜͡🧸 ${prefix}vozmenino (marca)
╰════════════════════╮`
}

exports.menumods= menumods