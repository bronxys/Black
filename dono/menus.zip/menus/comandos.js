const menuprime = (pushname, date, hora120, isVip, pushnames, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
『 𝐈𝐍𝐅𝐎 』
╭══════════════════╯
⏤͟͟͞͞ ꦿ𝙉𝙄𝘾𝙆: ${pushname}
⏤͟͟͞͞ ꦿ𝘿𝘼𝙏𝘼: ${date}
⏤͟͟͞͞ ꦿ𝙃𝙊𝙍𝘼: ${hora120}
⏤͟͟͞͞ ꦿ𝙑𝙄𝙋: ${isVip ? 'Sim ✅' : 'Não ❌'}
⏤͟͟͞͞ ꦿ𝙏𝙊𝙏𝘼𝙇 𝘿𝙀
    𝙐𝙎𝙐𝘼́𝙍𝙄𝙊𝙎 ->『 ${pushnames.length} 』
╰══════════════════╮
『 𝐌𝐄𝐍𝐔𝐒 』
╭══════════════════╯
 | ೈ፝͜͡🎗️ ${prefix}menuadm
 | ೈ፝͜͡🤪 ${prefix}menuzoeira
 | ೈ፝͜͡❤️‍🔥 ${prefix}menutinder
 | ೈ፝͜͡🎮 ${prefix}menujogos
 | ೈ፝͜͡🧩 ${prefix}menuefeitos
 | ೈ፝͜͡🧸 ${prefix}menumods
 | ೈ፝͜͡💝 ${prefix}menufigu
 | ೈ፝͜͡😃 ${prefix}menuemoji
 | ೈ፝͜͡💿 ${prefix}menudownloads
 | ೈ፝͜͡📜 ${prefix}menulogos
 | ೈ፝͜͡🤑 ${prefix}menuvip
 | ೈ፝͜͡🔞 ${prefix}menu+18
 | ೈ፝͜͡🔱 ${prefix}menudono
╰══════════════════╮ 
『 𝐈𝐍𝐅𝐎✮𝐆𝐄𝐑𝐀𝐋 』
╭══════════════════╯
 | ೈ፝͜͡📋 ${prefix}Infoblack
 | ೈ፝͜͡📋 ${prefix}Infotransmitir
 | ೈ፝͜͡📋 ${prefix}Infoaluguel
 | ೈ፝͜͡📋 ${prefix}infovip
 | ೈ፝͜͡📋 ${prefix}inforoleta
 | ೈ፝͜͡📋 ${prefix}infomute
 | ೈ፝͜͡📋 ${prefix}Infomultiprefixo
 | ೈ፝͜͡📋 ${prefix}Infobemvindo
 | ೈ፝͜͡📋 ${prefix}Infopalavrão
 | ೈ፝͜͡📋 ${prefix}Infolistanegra
 | ೈ፝͜͡📋 ${prefix}Infobancarac
 | ೈ፝͜͡📋 ${prefix}Infobanghost
 | ೈ፝͜͡📋 ${prefix}Infosorteio 
 | ೈ፝͜͡📋 ${prefix}Infoanotação
 | ೈ፝͜͡📋 ${prefix}infocorreio
╰══════════════════╮
『 𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 』
╭══════════════════╯
 | ೈ፝͜͡☯️ ${prefix}Lucas
 | ೈ፝͜͡☯️ ${prefix}Matty
 | ೈ፝͜͡☯️ ${prefix}Marcos
 | ೈ፝͜͡☯️ ${prefix}Katy
 | ೈ፝͜͡☯️ ${prefix}Jeff
 | ೈ፝͜͡☯️ ${prefix}clima
 | ೈ፝͜͡☯️ ${prefix}checkme
 | ೈ፝͜͡☯️ ${prefix}checkativo
 | ೈ፝͜͡☯️ ${prefix}tagme
 | ೈ፝͜͡☯️ ${prefix}lucas
 | ೈ፝͜͡☯️ ${prefix}frases
 | ೈ፝͜͡☯️ ${prefix}conselhos
 | ೈ፝͜͡☯️ ${prefix}infobot
 | ೈ፝͜͡☯️ ${prefix}ping
 | ೈ፝͜͡☯️ ${prefix}perfil
 | ೈ፝͜͡☯️ ${prefix}calcular 1+1
 | ೈ፝͜͡☯️ ${prefix}nick
 | ೈ፝͜͡☯️ ${prefix}gtts pt
 | ೈ፝͜͡☯️ ${prefix}idiomas 
 | ೈ፝͜͡☯️ ${prefix}black
 | ೈ፝͜͡☯️ ${prefix}blackgp
 | ೈ፝͜͡☯️ ${prefix}blacksite
 | ೈ፝͜͡☯️ ${prefix}alugar
 | ೈ፝͜͡☯️ ${prefix}help
 | ೈ፝͜͡☯️ ${prefix}bug
 | ೈ፝͜͡☯️ ${prefix}sugestão
 | ೈ፝͜͡☯️ ${prefix}avalie
 | ೈ፝͜͡☯️ ${prefix}suporte
 | ೈ፝͜͡☯️ ${prefix}comandos-termux 
 | ೈ፝͜͡☯️ ${prefix}comprarbot 
╰══════════════════╮`
}

exports.menuprime = menuprime