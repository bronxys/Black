const menudono = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✮𝐃𝐎𝐍𝐎 』
╭════════════════════╯
 | ೈ፝͜͡🔱 ${prefix}bangp
 | ೈ፝͜͡🔱 ${prefix}unbangp
 | ೈ፝͜͡🔱 ${prefix}join (entrar no grupo)
 | ೈ፝͜͡🔱 ${prefix}sair (sair do grupo)
 | ೈ፝͜͡🔱 ${prefix}sairdogp
 | ೈ፝͜͡🔱 ${prefix}fotomenu
 | ೈ፝͜͡🔱 ${prefix}logomenu
 | ೈ፝͜͡🔱 ${prefix}fotobot
 | ೈ፝͜͡🔱 ${prefix}nick-dono 
 | ೈ፝͜͡🔱 ${prefix}nome-bot 
 | ೈ፝͜͡🔱 ${prefix}clonar (marcar foto)
 | ೈ፝͜͡🔱 ${prefix}setprefix
 | ೈ፝͜͡🔱 ${prefix}tm (transmissão global)
 | ೈ፝͜͡🔱 ${prefix}nuke (arquivar grupo)
 | ೈ፝͜͡🔱 ${prefix}blockcmd
 | ೈ፝͜͡🔱 ${prefix}unblockcmd
 | ೈ፝͜͡🔱 ${prefix}listacomandos
 | ೈ፝͜͡🔱 ${prefix}block @
 | ೈ፝͜͡🔱 ${prefix}unblock @
 | ೈ፝͜͡🔱 ${prefix}blocklist
 | ೈ፝͜͡🔱 ${prefix}bcgp (TM no PV)
 | ೈ፝͜͡🔱 ${prefix}anticall 1/0 (call PV)
 | ೈ፝͜͡🔱 ${prefix}servip
 | ೈ፝͜͡🔱 ${prefix}addvip
 | ೈ፝͜͡🔱 ${prefix}delvip
 | ೈ፝͜͡🔱 ${prefix}idgp
 | ೈ፝͜͡🔱 ${prefix}listagp
 | ೈ፝͜͡🔱 ${prefix}linkdogp
 | ೈ፝͜͡🔱 ${prefix}iddogp
 | ೈ፝͜͡🔱 ${prefix}addrent
 | ೈ፝͜͡🔱 ${prefix}delrent
 | ೈ፝͜͡🔱 ${prefix}listrent
 | ೈ፝͜͡🔱 ${prefix}envmsg
 | ೈ፝͜͡🔱 ${prefix}msgpv
 | ೈ፝͜͡🔱 ${prefix}ausente
 | ೈ፝͜͡🔱 ${prefix}voltei
 | ೈ፝͜͡🔱 ${prefix}rmtinder
 | ೈ፝͜͡🔱 ${prefix}autobang
 | ೈ፝͜͡🔱 ${prefix}delautobang
 | ೈ፝͜͡🔱 ${prefix}globalblocklist
 | ೈ፝͜͡🔱 ${prefix}s2
 | ೈ፝͜͡🔱 ${prefix}multiprefixo
 | ೈ፝͜͡🔱 ${prefix}addprefixo
 | ೈ፝͜͡🔱 ${prefix}delprefixo
 | ೈ፝͜͡🔱 ${prefix}prefixos
 | ೈ፝͜͡🔱 ${prefix}addxp
 | ೈ፝͜͡🔱 ${prefix}tirarxp
 | ೈ፝͜͡🔱 ${prefix}addlevel
 | ೈ፝͜͡🔱 ${prefix}tirarlevel
 | ೈ፝͜͡🔱 ${prefix}visualizarmsg
 | ೈ፝͜͡🔱 ${prefix}console
 | ೈ፝͜͡🔱 ${prefix}gitbot
 | ೈ፝͜͡🔱 ${prefix}configurar-bot
╰════════════════════╮`
}

exports.menudono = menudono